﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace DirectoryMonitorService
{
    public partial class DirectoryMonitorService : ServiceBase
    {
        FileSystemWatcher fileSystemWatcher;
        public DirectoryMonitorService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            // EventLog.WriteEntry("Directory Monitor Service Started");
            fileSystemWatcher = new FileSystemWatcher("C:\\TargetFolder")
            {
                EnableRaisingEvents = true,
            };
            fileSystemWatcher.Created += DirectoryChanged;
            fileSystemWatcher.Deleted += DirectoryChanged;
            fileSystemWatcher.Renamed += DirectoryChanged;
        
        }

        private void DirectoryChanged(object sender, FileSystemEventArgs e)
        {
            var msg = $"{e.ChangeType} - {e.FullPath}{System.Environment.NewLine}";
            var serviceLocation = Path.GetDirectoryName(System.Reflection.Assembly.GetEntryAssembly().Location);
            File.AppendAllText($"{serviceLocation}\\File Tracker.txt", msg) ;
        }

        protected override void OnStop()
        {
           // EventLog.WriteEntry("Directory Monitor Service Stopped");
        }
    }
}
